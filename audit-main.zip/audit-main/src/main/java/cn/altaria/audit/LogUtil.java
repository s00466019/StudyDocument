package cn.altaria.audit;

import cn.altaria.audit.enums.Result;
import cn.altaria.audit.pojo.AuditLogRecord;
import org.springframework.stereotype.Service;

@Service
public class LogUtil {
    public static ThreadLocal<AuditLogRecord> record = new ThreadLocal<>();

    public void logSuccess(String detail) {
        record.set(new AuditLogRecord().setDetail(detail).setResult(Result.SUCCESS.getResultName()));
    }

    public void logFailed(String detail) {
        record.set(new AuditLogRecord().setDetail(detail).setResult(Result.FAILED.getResultName()));
    }
}
