package cn.altaria.audit.enums;

public enum Result {
    SUCCESS(0,"SUCCESS"),
    FAILED(1,"FAILED"),
    PART_SUCCESS(2,"PART_SUCCESS");

    public int code;
    public String resultName;

    Result(int code, String resultName) {
        this.code = code;
        this.resultName = resultName;
    }

    public String getResultName() {
        return resultName;
    }

    public int getCode() {
        return code;
    }
}
