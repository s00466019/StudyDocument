package cn.altaria.audit.pojo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

@Setter
@Getter
@ToString
@Accessors(chain = true)
public class AuditLogRecord implements Serializable {
    private String user;

    private Date operateTime;

    private String ip;

    private String module;

    private Integer type;

    private String detail;

    private String result;
}
